# site_de_commerce_electronique_PHP
Nous nous proposons de créer un site de commerce électronique. Les produits de notre boutique sont fournis dans un fichier “products.json” Les clients pourront chercher les produits qu’ils désirent et les ajouter dans leur panier. S’ils souhaitent finaliser leurs achats, ils devront s’inscrire pour valider leur commande.
